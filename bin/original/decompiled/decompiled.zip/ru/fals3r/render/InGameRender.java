package ru.fals3r.render;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import org.lwjgl.opengl.GL11;
import ru.fals3r.SkidForce;
import ru.fals3r.functions.Function;
import ru.fals3r.helpers.RenderHelper;
import ru.fals3r.hooks.ProfillerHook;

public class InGameRender {
   private static .bib mc;

   public static void doRender() {
      new .bit(mc);
      GL11.glPushMatrix();
      GL11.glScaled(2.0D, 2.0D, 2.0D);
      GL11.glTranslated(3.0D, 3.0D, 0.0D);
      mc.k.a("SkidForce", 0, 0, -16746560);
      GL11.glTranslated(-0.5D, -0.5D, 0.0D);
      mc.k.a("SkidForce", 0, 0, -14506000);
      GL11.glScaled(1.0D, 1.0D, 1.0D);
      GL11.glPopMatrix();
      mc.k.a("vk.com/skidforce", 5, 22, -6250336);
      GL11.glTranslated(-0.5D, -0.5D, 0.0D);
      mc.k.a("vk.com/skidforce", 5, 22, -2039584);
      drawArrayList();
   }

   private static void drawArrayList() {
      .bit scaledResolution = new .bit(mc);
      int sWidth = scaledResolution.a();
      int sHeight = scaledResolution.b();
      float ppp = -0.9F;
      Iterator var4 = sortedFunctions().iterator();

      while(var4.hasNext()) {
         Function func = (Function)var4.next();
         float yPosition = 12.0F * ppp;
         float plusNeed = 30.0F;
         String funcName = func.getName();
         String funcMod = func.getMode();
         int width = mc.k.a(funcName + funcMod);
         double sideOffset = func.offset();
         if (!func.getToggled()) {
            sideOffset = 1.0D - sideOffset;
         }

         if (sideOffset != 0.0D) {
            float toggleOffset = (float)Math.round((double)width * Math.sin(Math.toRadians(sideOffset * 90.0D)));
            int p = 6;
            int add = 0;
            RenderHelper.drawRect((double)(sWidth - 1), (double)(yPosition + 12.0F), (double)((float)(sWidth - p) - toggleOffset + 1.0F), (double)(yPosition + plusNeed - 8.4F), Integer.MIN_VALUE);
            RenderHelper.drawRect((double)((float)(sWidth - p) - toggleOffset + 2.0F), (double)(yPosition + 12.0F), (double)((float)(sWidth - p) - toggleOffset), (double)(yPosition + plusNeed - 8.4F), -855638017);
            mc.k.a(funcName + funcMod, (float)sWidth - toggleOffset + 4.0F - (float)p - (float)add, 13.5F + yPosition, Color.WHITE.getRGB());
            ppp += 0.8F;
         }
      }

   }

   private static List<Function> sortedFunctions() {
      ArrayList<Function> list = new ArrayList();
      Iterator var1 = SkidForce.functionManager.functions().iterator();

      while(var1.hasNext()) {
         Function func = (Function)var1.next();
         list.add(func);
      }

      Comparator<Function> cp = new Comparator<Function>() {
         public int compare(Function b1, Function b2) {
            String s1 = b1.getName();
            String s2 = b2.getName();
            s1 = String.format("%s%s", b1.getName(), b1.getMode());
            s2 = String.format("%s%s", b2.getName(), b2.getMode());
            return Integer.compare(InGameRender.mc.k.a(s2), InGameRender.mc.k.a(s1));
         }
      };
      Collections.sort(list, cp);
      return list;
   }

   static {
      mc = ProfillerHook.mc;
   }
}
