package ru.fals3r.helpers;

import java.awt.Color;
import org.lwjgl.opengl.GL11;

public class RenderHelper {
   private static .bib mc = .bib.z();

   public static void glRenderStart() {
      GL11.glPushMatrix();
      GL11.glPushAttrib(1048575);
      GL11.glEnable(3042);
      GL11.glDisable(2884);
      GL11.glDisable(3553);
   }

   public static void glRenderStop() {
      GL11.glEnable(3553);
      GL11.glEnable(2884);
      GL11.glDisable(3042);
      GL11.glPopAttrib();
      GL11.glPopMatrix();
   }

   public static float convertColor(int count, int color) {
      return (float)(color >> count & 255) / 255.0F;
   }

   public static void setColor(Color c) {
      GL11.glColor4d((double)((float)c.getRed() / 255.0F), (double)((float)c.getGreen() / 255.0F), (double)((float)c.getBlue() / 255.0F), (double)((float)c.getAlpha() / 255.0F));
   }

   public static void drawGradient(double x, double y, double x2, double y2, int col1, int col2) {
      float f = (float)(col1 >> 24 & 255) / 255.0F;
      float f2 = (float)(col1 >> 16 & 255) / 255.0F;
      float f3 = (float)(col1 >> 8 & 255) / 255.0F;
      float f4 = (float)(col1 & 255) / 255.0F;
      float f5 = (float)(col2 >> 24 & 255) / 255.0F;
      float f6 = (float)(col2 >> 16 & 255) / 255.0F;
      float f7 = (float)(col2 >> 8 & 255) / 255.0F;
      float f8 = (float)(col2 & 255) / 255.0F;
      glRenderStart();
      GL11.glEnable(3042);
      GL11.glDisable(3553);
      GL11.glBlendFunc(770, 771);
      GL11.glEnable(2848);
      GL11.glShadeModel(7425);
      GL11.glPushMatrix();
      GL11.glBegin(7);
      GL11.glColor4f(f2, f3, f4, f);
      GL11.glVertex2d(x2, y);
      GL11.glVertex2d(x, y);
      GL11.glColor4f(f6, f7, f8, f5);
      GL11.glVertex2d(x, y2);
      GL11.glVertex2d(x2, y2);
      GL11.glEnd();
      GL11.glPopMatrix();
      GL11.glEnable(3553);
      GL11.glDisable(3042);
      GL11.glDisable(2848);
      GL11.glShadeModel(7424);
      GL11.glColor4d(1.0D, 1.0D, 1.0D, 1.0D);
      glRenderStop();
   }

   public static void drawGradientSideways(double left, double top, double right, double bottom, int col1, int col2) {
      float f = (float)(col1 >> 24 & 255) / 255.0F;
      float f2 = (float)(col1 >> 16 & 255) / 255.0F;
      float f3 = (float)(col1 >> 8 & 255) / 255.0F;
      float f4 = (float)(col1 & 255) / 255.0F;
      float f5 = (float)(col2 >> 24 & 255) / 255.0F;
      float f6 = (float)(col2 >> 16 & 255) / 255.0F;
      float f7 = (float)(col2 >> 8 & 255) / 255.0F;
      float f8 = (float)(col2 & 255) / 255.0F;
      glRenderStart();
      GL11.glEnable(3042);
      GL11.glDisable(3553);
      GL11.glBlendFunc(770, 771);
      GL11.glEnable(2848);
      GL11.glShadeModel(7425);
      GL11.glPushMatrix();
      GL11.glBegin(7);
      GL11.glColor4f(f2, f3, f4, f);
      GL11.glVertex2d(left, top);
      GL11.glVertex2d(left, bottom);
      GL11.glColor4f(f6, f7, f8, f5);
      GL11.glVertex2d(right, bottom);
      GL11.glVertex2d(right, top);
      GL11.glEnd();
      GL11.glPopMatrix();
      GL11.glEnable(3553);
      GL11.glDisable(3042);
      GL11.glDisable(2848);
      GL11.glShadeModel(7424);
      glRenderStop();
   }

   public static void drawRect(double x, double y, double d, double e, int color) {
      float alpha = (float)(color >> 24 & 255) / 255.0F;
      float red = (float)(color >> 16 & 255) / 255.0F;
      float green = (float)(color >> 8 & 255) / 255.0F;
      float blue = (float)(color & 255) / 255.0F;
      glRenderStart();
      GL11.glColor4f(red, green, blue, alpha);
      GL11.glBegin(7);
      GL11.glVertex2d(x, y);
      GL11.glVertex2d(d, y);
      GL11.glVertex2d(d, e);
      GL11.glVertex2d(x, e);
      GL11.glEnd();
      glRenderStop();
   }

   public static void drawBorderedRect(float xPos, float yPos, float width, float height, float lineWidth, int lineColor, int bgColor) {
      drawRect((double)xPos, (double)yPos, (double)width, (double)height, bgColor);
      float alpha = (float)(lineColor >> 24 & 255) / 255.0F;
      float red = (float)(lineColor >> 16 & 255) / 255.0F;
      float green = (float)(lineColor >> 8 & 255) / 255.0F;
      float blue = (float)(lineColor & 255) / 255.0F;
      glRenderStart();
      GL11.glColor4f(red, green, blue, alpha);
      GL11.glLineWidth(lineWidth);
      GL11.glEnable(2848);
      GL11.glBegin(1);
      GL11.glVertex2d((double)xPos, (double)yPos);
      GL11.glVertex2d((double)width, (double)yPos);
      GL11.glVertex2d((double)width, (double)yPos);
      GL11.glVertex2d((double)width, (double)height);
      GL11.glVertex2d((double)width, (double)height);
      GL11.glVertex2d((double)xPos, (double)height);
      GL11.glVertex2d((double)xPos, (double)height);
      GL11.glVertex2d((double)xPos, (double)yPos);
      GL11.glEnd();
      glRenderStop();
   }

   public static void drawOctagon(float xPos, float yPos, float width, float height, float length, float angle, int color) {
      float alpha = convertColor(24, color);
      float red = convertColor(16, color);
      float green = convertColor(8, color);
      float blue = convertColor(0, color);
      glRenderStart();
      GL11.glColor4f(red, green, blue, alpha);
      GL11.glBegin(9);
      GL11.glVertex2d((double)(xPos + length), (double)yPos);
      GL11.glVertex2d((double)(xPos + width - length), (double)yPos);
      GL11.glVertex2d((double)(xPos + width - length), (double)yPos);
      GL11.glVertex2d((double)(xPos + width), (double)(yPos + height / 2.0F - angle));
      GL11.glVertex2d((double)(xPos + width), (double)(yPos + height / 2.0F - angle));
      GL11.glVertex2d((double)(xPos + width), (double)(yPos + height / 2.0F + angle));
      GL11.glVertex2d((double)(xPos + width), (double)(yPos + height / 2.0F + angle));
      GL11.glVertex2d((double)(xPos + width - length), (double)(yPos + height));
      GL11.glVertex2d((double)(xPos + width - length), (double)(yPos + height));
      GL11.glVertex2d((double)(xPos + length), (double)(yPos + height));
      GL11.glVertex2d((double)(xPos + length), (double)(yPos + height));
      GL11.glVertex2d((double)xPos, (double)(yPos + height / 2.0F + angle));
      GL11.glVertex2d((double)xPos, (double)(yPos + height / 2.0F + angle));
      GL11.glVertex2d((double)xPos, (double)(yPos + height / 2.0F - angle));
      GL11.glVertex2d((double)xPos, (double)(yPos + height / 2.0F - angle));
      GL11.glVertex2d((double)(xPos + length), (double)yPos);
      GL11.glEnd();
      glRenderStop();
   }

   public static void drawImage(.nf image, int x, int y, int width, int height) {
      new .bit(mc);
      GL11.glPushMatrix();
      .bus.m();
      .bus.e();
      .bib.z().N().a(image);
      .bir.a(x, y, 0.0F, 0.0F, width, height, (float)width, (float)height);
      GL11.glPopMatrix();
   }

   public static void drawImage(.nf image, int x, int y, int width, int height, Color color) {
      new .bit(.bib.z());
      GL11.glDisable(2929);
      GL11.glEnable(3042);
      GL11.glDepthMask(false);
      .cii.c(770, 771, 1, 0);
      GL11.glColor4f((float)color.getRed() / 255.0F, (float)color.getBlue() / 255.0F, (float)color.getRed() / 255.0F, 1.0F);
      .bib.z().N().a(image);
      .bir.a(x, y, 0.0F, 0.0F, width, height, (float)width, (float)height);
      GL11.glDepthMask(true);
      GL11.glDisable(3042);
      GL11.glEnable(2929);
   }

   public static void drawBorderedCircle(float x, float y, float radius, int lineWidth, int outsideC, int insideC) {
      drawCircle(x, y, radius, insideC);
      drawUnfilledCircle(x, y, radius, (float)lineWidth, outsideC);
   }

   public static void drawCircle228(float x, float y, float radius, int lineWidth, int outsideC, int insideC, int jopaSlona) {
      drawCircle228(x, y, radius, insideC, jopaSlona);
   }

   public static void drawUnfilledCircle228(float x, float y, float radius, float lineWidth, int color, int jopaSlona) {
      float red = (float)(color >> 16 & 255) / 255.0F;
      float green = (float)(color >> 8 & 255) / 255.0F;
      float blue = (float)(color & 255) / 255.0F;
      float f = (float)(color >> 24 & 255) / 255.0F;
      GL11.glEnable(2848);
      GL11.glEnable(3042);
      GL11.glDisable(3553);
      GL11.glBlendFunc(770, 771);
      GL11.glDepthMask(true);
      GL11.glEnable(2848);
      GL11.glHint(3154, 4354);
      GL11.glHint(3155, 4354);
      .bus.m();
      GL11.glColor4f(red, green, blue, f);
      GL11.glLineWidth(lineWidth);
      GL11.glBegin(2);

      for(int i = 0; i <= jopaSlona; ++i) {
         GL11.glVertex2d((double)x + Math.sin((double)i * 3.141592653589793D / 180.0D) * (double)radius, (double)y + Math.cos((double)i * 3.141592653589793D / 180.0D) * (double)radius);
      }

      GL11.glEnd();
      GL11.glScalef(2.0F, 2.0F, 2.0F);
      GL11.glEnable(3553);
      GL11.glDisable(3042);
      GL11.glDisable(2848);
      GL11.glHint(3154, 4352);
      GL11.glHint(3155, 4352);
      .bus.l();
   }

   public static void drawUnfilledCircle(float x, float y, float radius, float lineWidth, int color) {
      float red = (float)(color >> 16 & 255) / 255.0F;
      float green = (float)(color >> 8 & 255) / 255.0F;
      float blue = (float)(color & 255) / 255.0F;
      float f = (float)(color >> 24 & 255) / 255.0F;
      GL11.glEnable(2848);
      GL11.glEnable(3042);
      GL11.glDisable(3553);
      GL11.glBlendFunc(770, 771);
      GL11.glDepthMask(true);
      GL11.glEnable(2848);
      GL11.glHint(3154, 4354);
      GL11.glHint(3155, 4354);
      .bus.m();
      GL11.glColor4f(red, green, blue, f);
      GL11.glLineWidth(lineWidth);
      GL11.glBegin(2);

      for(int i = 0; i <= 360; ++i) {
         GL11.glVertex2d((double)x + Math.sin((double)i * 3.141592653589793D / 180.0D) * (double)radius, (double)y + Math.cos((double)i * 3.141592653589793D / 180.0D) * (double)radius);
      }

      GL11.glEnd();
      GL11.glScalef(2.0F, 2.0F, 2.0F);
      GL11.glEnable(3553);
      GL11.glDisable(3042);
      GL11.glDisable(2848);
      GL11.glHint(3154, 4352);
      GL11.glHint(3155, 4352);
      .bus.l();
   }

   public static void drawCircle228(float x, float y, float radius, int color, int jopaSlona) {
      float alpha = (float)(color >> 24 & 255) / 255.0F;
      float red = (float)(color >> 16 & 255) / 255.0F;
      float green = (float)(color >> 8 & 255) / 255.0F;
      float blue = (float)(color & 255) / 255.0F;
      boolean blend = GL11.glIsEnabled(3042);
      boolean line = GL11.glIsEnabled(2848);
      boolean texture = GL11.glIsEnabled(3553);
      if (!blend) {
         GL11.glEnable(3042);
      }

      if (!line) {
         GL11.glEnable(2848);
      }

      if (texture) {
         GL11.glDisable(3553);
      }

      GL11.glEnable(2848);
      GL11.glBlendFunc(770, 771);
      GL11.glColor4f(red, green, blue, alpha);
      GL11.glLineWidth(2.5F);
      GL11.glBegin(3);

      for(int i = 0; i <= jopaSlona; ++i) {
         GL11.glVertex2d((double)x + Math.sin((double)i * 3.1415926535D / 180.0D) * (double)radius, (double)y + Math.cos((double)i * 3.1415926535D / 180.0D) * (double)radius);
      }

      GL11.glEnd();
      GL11.glDisable(2848);
      if (texture) {
         GL11.glEnable(3553);
      }

      if (!line) {
         GL11.glDisable(2848);
      }

      if (!blend) {
         GL11.glDisable(3042);
      }

   }

   public static void drawCircle(float x, float y, float radius, int color) {
      float alpha = (float)(color >> 24 & 255) / 255.0F;
      float red = (float)(color >> 16 & 255) / 255.0F;
      float green = (float)(color >> 8 & 255) / 255.0F;
      float blue = (float)(color & 255) / 255.0F;
      boolean blend = GL11.glIsEnabled(3042);
      boolean line = GL11.glIsEnabled(2848);
      boolean texture = GL11.glIsEnabled(3553);
      if (!blend) {
         GL11.glEnable(3042);
      }

      if (!line) {
         GL11.glEnable(2848);
      }

      if (texture) {
         GL11.glDisable(3553);
      }

      GL11.glEnable(2848);
      GL11.glBlendFunc(770, 771);
      GL11.glColor4f(red, green, blue, alpha);
      GL11.glBegin(9);

      for(int i = 0; i <= 360; ++i) {
         GL11.glVertex2d((double)x + Math.sin((double)i * 3.1415926535D / 180.0D) * (double)radius, (double)y + Math.cos((double)i * 3.1415926535D / 180.0D) * (double)radius);
      }

      GL11.glEnd();
      GL11.glDisable(2848);
      if (texture) {
         GL11.glEnable(3553);
      }

      if (!line) {
         GL11.glDisable(2848);
      }

      if (!blend) {
         GL11.glDisable(3042);
      }

   }

   public static void enableScissoring() {
      GL11.glEnable(3089);
   }

   public static void doGlScissor(int x, int y, int width, int height) {
      if (x != width && y != height) {
         .bib mc = .bib.z();
         int scaleFactor = 1;

         for(int k = mc.t.aG; scaleFactor < k && mc.d / (scaleFactor + 1) >= 320 && mc.e / (scaleFactor + 1) >= 240; ++scaleFactor) {
         }

         GL11.glScissor(x * scaleFactor, mc.e - (y + height) * scaleFactor, width * scaleFactor, height * scaleFactor);
      }
   }

   public static void disableScissoring() {
      GL11.glDisable(3089);
   }

   public static void drawLines(.bhb mask) {
      GL11.glPushMatrix();
      GL11.glBegin(2);
      GL11.glVertex3d(mask.a, mask.b, mask.c);
      GL11.glVertex3d(mask.a, mask.e, mask.f);
      GL11.glEnd();
      GL11.glBegin(2);
      GL11.glVertex3d(mask.a, mask.e, mask.c);
      GL11.glVertex3d(mask.a, mask.b, mask.f);
      GL11.glEnd();
      GL11.glBegin(2);
      GL11.glVertex3d(mask.d, mask.b, mask.c);
      GL11.glVertex3d(mask.d, mask.e, mask.f);
      GL11.glEnd();
      GL11.glBegin(2);
      GL11.glVertex3d(mask.d, mask.e, mask.c);
      GL11.glVertex3d(mask.d, mask.b, mask.f);
      GL11.glEnd();
      GL11.glBegin(2);
      GL11.glVertex3d(mask.d, mask.b, mask.f);
      GL11.glVertex3d(mask.a, mask.e, mask.f);
      GL11.glEnd();
      GL11.glBegin(2);
      GL11.glVertex3d(mask.d, mask.e, mask.f);
      GL11.glVertex3d(mask.a, mask.b, mask.f);
      GL11.glEnd();
      GL11.glBegin(2);
      GL11.glVertex3d(mask.d, mask.b, mask.c);
      GL11.glVertex3d(mask.a, mask.e, mask.c);
      GL11.glEnd();
      GL11.glBegin(2);
      GL11.glVertex3d(mask.d, mask.e, mask.c);
      GL11.glVertex3d(mask.a, mask.b, mask.c);
      GL11.glEnd();
      GL11.glBegin(2);
      GL11.glVertex3d(mask.a, mask.e, mask.c);
      GL11.glVertex3d(mask.d, mask.e, mask.f);
      GL11.glEnd();
      GL11.glBegin(2);
      GL11.glVertex3d(mask.d, mask.e, mask.c);
      GL11.glVertex3d(mask.a, mask.e, mask.f);
      GL11.glEnd();
      GL11.glBegin(2);
      GL11.glVertex3d(mask.a, mask.b, mask.c);
      GL11.glVertex3d(mask.d, mask.b, mask.f);
      GL11.glEnd();
      GL11.glBegin(2);
      GL11.glVertex3d(mask.d, mask.b, mask.c);
      GL11.glVertex3d(mask.a, mask.b, mask.f);
      GL11.glEnd();
      GL11.glPopMatrix();
   }

   public static void drawColorBox(.bhb axisalignedbb) {
      .bve ts = .bve.a();
      .buk wr = ts.c();
      int lol = true;
      wr.a(7, .cdy.e);
      wr.b(axisalignedbb.a, axisalignedbb.b, axisalignedbb.c).d();
      wr.b(axisalignedbb.a, axisalignedbb.e, axisalignedbb.c).d();
      wr.b(axisalignedbb.d, axisalignedbb.b, axisalignedbb.c).d();
      wr.b(axisalignedbb.d, axisalignedbb.e, axisalignedbb.c).d();
      wr.b(axisalignedbb.d, axisalignedbb.b, axisalignedbb.f).d();
      wr.b(axisalignedbb.d, axisalignedbb.e, axisalignedbb.f).d();
      wr.b(axisalignedbb.a, axisalignedbb.b, axisalignedbb.f).d();
      wr.b(axisalignedbb.a, axisalignedbb.e, axisalignedbb.f).d();
      ts.b();
      wr.a(7, .cdy.e);
      wr.b(axisalignedbb.d, axisalignedbb.e, axisalignedbb.c).d();
      wr.b(axisalignedbb.d, axisalignedbb.b, axisalignedbb.c).d();
      wr.b(axisalignedbb.a, axisalignedbb.e, axisalignedbb.c).d();
      wr.b(axisalignedbb.a, axisalignedbb.b, axisalignedbb.c).d();
      wr.b(axisalignedbb.a, axisalignedbb.e, axisalignedbb.f).d();
      wr.b(axisalignedbb.a, axisalignedbb.b, axisalignedbb.f).d();
      wr.b(axisalignedbb.d, axisalignedbb.e, axisalignedbb.f).d();
      wr.b(axisalignedbb.d, axisalignedbb.b, axisalignedbb.f).d();
      ts.b();
      wr.a(7, .cdy.e);
      wr.b(axisalignedbb.a, axisalignedbb.e, axisalignedbb.c).d();
      wr.b(axisalignedbb.d, axisalignedbb.e, axisalignedbb.c).d();
      wr.b(axisalignedbb.d, axisalignedbb.e, axisalignedbb.f).d();
      wr.b(axisalignedbb.a, axisalignedbb.e, axisalignedbb.f).d();
      wr.b(axisalignedbb.a, axisalignedbb.e, axisalignedbb.c).d();
      wr.b(axisalignedbb.a, axisalignedbb.e, axisalignedbb.f).d();
      wr.b(axisalignedbb.d, axisalignedbb.e, axisalignedbb.f).d();
      wr.b(axisalignedbb.d, axisalignedbb.e, axisalignedbb.c).d();
      ts.b();
      wr.a(7, .cdy.e);
      wr.b(axisalignedbb.a, axisalignedbb.b, axisalignedbb.c).d();
      wr.b(axisalignedbb.d, axisalignedbb.b, axisalignedbb.c).d();
      wr.b(axisalignedbb.d, axisalignedbb.b, axisalignedbb.f).d();
      wr.b(axisalignedbb.a, axisalignedbb.b, axisalignedbb.f).d();
      wr.b(axisalignedbb.a, axisalignedbb.b, axisalignedbb.c).d();
      wr.b(axisalignedbb.a, axisalignedbb.b, axisalignedbb.f).d();
      wr.b(axisalignedbb.d, axisalignedbb.b, axisalignedbb.f).d();
      wr.b(axisalignedbb.d, axisalignedbb.b, axisalignedbb.c).d();
      ts.b();
      wr.a(7, .cdy.e);
      wr.b(axisalignedbb.a, axisalignedbb.b, axisalignedbb.c).d();
      wr.b(axisalignedbb.a, axisalignedbb.e, axisalignedbb.c).d();
      wr.b(axisalignedbb.a, axisalignedbb.b, axisalignedbb.f).d();
      wr.b(axisalignedbb.a, axisalignedbb.e, axisalignedbb.f).d();
      wr.b(axisalignedbb.d, axisalignedbb.b, axisalignedbb.f).d();
      wr.b(axisalignedbb.d, axisalignedbb.e, axisalignedbb.f).d();
      wr.b(axisalignedbb.d, axisalignedbb.b, axisalignedbb.c).d();
      wr.b(axisalignedbb.d, axisalignedbb.e, axisalignedbb.c).d();
      ts.b();
      wr.a(7, .cdy.e);
      wr.b(axisalignedbb.a, axisalignedbb.e, axisalignedbb.f).d();
      wr.b(axisalignedbb.a, axisalignedbb.b, axisalignedbb.f).d();
      wr.b(axisalignedbb.a, axisalignedbb.e, axisalignedbb.c).d();
      wr.b(axisalignedbb.a, axisalignedbb.b, axisalignedbb.c).d();
      wr.b(axisalignedbb.d, axisalignedbb.e, axisalignedbb.c).d();
      wr.b(axisalignedbb.d, axisalignedbb.b, axisalignedbb.c).d();
      wr.b(axisalignedbb.d, axisalignedbb.e, axisalignedbb.f).d();
      wr.b(axisalignedbb.d, axisalignedbb.b, axisalignedbb.f).d();
      ts.b();
   }

   public static void fuckerESP(.et blockPos, float red, float green, float blue) {
      GL11.glPushMatrix();
      double n = (double)blockPos.p();
      .bib.z().ac();
      double x = n - .bwx.b;
      double n2 = (double)blockPos.q();
      .bib.z().ac();
      double y = n2 - .bwx.c;
      double n3 = (double)blockPos.r();
      .bib.z().ac();
      double z = n3 - .bwx.d;
      GL11.glBlendFunc(770, 771);
      GL11.glEnable(3042);
      GL11.glLineWidth(10.0F);
      .aow block = mc.f.o(blockPos).u();
      GL11.glDisable(3553);
      GL11.glDisable(2929);
      GL11.glDepthMask(false);
      GL11.glColor4d(0.2D, 0.5D, 1.0D, 0.4000000596046448D);
      drawColorBox(new .bhb(x, y, z, x + 1.0D, y + 1.0D, z + 1.0D));
      GL11.glColor4d(0.2D, 0.5D, 1.0D, 0.6000000596046448D);
      .buy.b(new .bhb(x, y, z, x + 1.0D, y + 1.0D, z + 1.0D), red, green, blue, 0.6F);
      GL11.glColor4d(0.0D, 0.0D, 0.0D, 1.0D);
      GL11.glEnable(3553);
      GL11.glEnable(2929);
      GL11.glDepthMask(true);
      GL11.glDisable(3042);
      setColor(Color.WHITE);
      GL11.glPopMatrix();
   }

   public static void entityESPBox(.vg entity, float r, float g, float b, float a) {
      GL11.glBlendFunc(770, 771);
      GL11.glEnable(3042);
      GL11.glLineWidth(2.0F);
      GL11.glDisable(3553);
      GL11.glDisable(2929);
      GL11.glDepthMask(false);
      GL11.glColor4d((double)r, (double)g, (double)b, (double)a);
      .buy.a(new .bhb(entity.bx().a - 0.05D - entity.p + (entity.p - .bwx.b), entity.bx().b - entity.q + (entity.q - .bwx.c), entity.bx().c - 0.05D - entity.r + (entity.r - .bwx.d), entity.bx().d + 0.05D - entity.p + (entity.p - .bwx.b), entity.bx().e + 0.1D - entity.q + (entity.q - .bwx.c), entity.bx().f + 0.05D - entity.r + (entity.r - .bwx.d)), r, g, b, a);
      GL11.glEnable(3553);
      GL11.glEnable(2929);
      GL11.glDepthMask(true);
      GL11.glDisable(3042);
   }
}
