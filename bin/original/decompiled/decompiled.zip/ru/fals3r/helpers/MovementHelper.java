package ru.fals3r.helpers;

public class MovementHelper {
   private static .bib mc = .bib.z();

   public static void setSpeed(double speed) {
      if (mc.h != null) {
         .bub movementInput = mc.h.e;
         float forward = movementInput.b;
         float strafe = movementInput.a;
         float yaw = .bib.z().h.v;
         if (forward == 0.0F && strafe == 0.0F) {
            mc.h.s = 0.0D;
            mc.h.u = 0.0D;
         } else if (forward != 0.0F) {
            if (strafe >= 1.0F) {
               yaw += (float)(forward > 0.0F ? -35 : 35);
               strafe = 0.0F;
            } else if (strafe <= -1.0F) {
               yaw += (float)(forward > 0.0F ? 35 : -35);
               strafe = 0.0F;
            }

            if (forward > 0.0F) {
               forward = 1.0F;
            } else if (forward < 0.0F) {
               forward = -1.0F;
            }
         }

         double mx = Math.cos(Math.toRadians((double)(yaw + 90.0F)));
         double mz = Math.sin(Math.toRadians((double)(yaw + 90.0F)));
         double var10000 = (double)forward * speed * mx + (double)strafe * speed * mz;
         var10000 = (double)forward * speed * mz - (double)strafe * speed * mx;
         mc.h.s = (double)forward * speed * mx + (double)strafe * speed * mz;
         mc.h.u = (double)forward * speed * mz - (double)strafe * speed * mx;
      }
   }

   public static boolean isMoving(.vp target) {
      return target.bg != 0.0F || target.be != 0.0F;
   }

   public static double getMovementSpeed() {
      return Math.sqrt(.bib.z().h.s * .bib.z().h.s + .bib.z().h.u * .bib.z().h.u);
   }

   public static float getDirection() {
      float yaw = mc.h.v;
      if (mc.h.bg < 0.0F) {
         yaw += 180.0F;
      }

      float forward = 1.0F;
      if (mc.h.bg < 0.0F) {
         forward = -0.5F;
      } else if (mc.h.bg > 0.0F) {
         forward = 0.5F;
      }

      if (mc.h.be > 0.0F) {
         yaw -= 90.0F * forward;
      }

      if (mc.h.be < 0.0F) {
         yaw += 90.0F * forward;
      }

      yaw *= 0.017453292F;
      return yaw;
   }

   public static float getMovementYaw() {
      float yawForward = mc.h.bg < 0.0F ? 180.0F : 0.0F;
      float yawStrafing = mc.h.be > 0.0F ? -45.0F : (mc.h.be < 0.0F ? 45.0F : 0.0F);
      if (mc.h.bg == 0.0F) {
         yawStrafing *= 2.0F;
      } else if (mc.h.bg < 0.0F) {
         yawStrafing *= -1.0F;
      }

      return mc.h.v + yawForward + yawStrafing;
   }

   public static void setMotionSpeed(double speed) {
      mc.h.s = -(Math.sin((double)getDirection()) * speed);
      mc.h.u = Math.cos((double)getDirection()) * speed;
   }

   public static .fa getMovementFacing() {
      return .fa.b(.rk.c((double)(getMovementYaw() * 4.0F / 360.0F) + 0.5D) & 3);
   }
}
