package ru.fals3r.helpers;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Random;
import org.lwjgl.input.Keyboard;

public class MathHelper {
   private static .bib mc = .bib.z();
   public static .bih timer;

   public MathHelper() {
      try {
         Field f = getField(.bib.class, "B:field_71424_I:profiler");
         Field modifiersField = getField(Field.class, "modifiers");
         modifiersField.setInt(f, f.getModifiers() & -17);
         f.set(.bib.z(), this);
         Field tm = getField(.bib.class, "Y:field_71428_T:timer");
         timer = (.bih)tm.get(.bib.z());
      } catch (Exception var4) {
      }

   }

   public static Field getField(Class cl, String name) {
      String[] var6;
      int var5 = (var6 = name.split(":")).length;
      int var7 = 0;

      while(var7 < var5) {
         String s1 = var6[var7];

         try {
            Field f = cl.getDeclaredField(s1);
            f.setAccessible(true);
            return f;
         } catch (Exception var7) {
            ++var7;
         }
      }

      return null;
   }

   public static int getRandomInt(int min, int max) {
      Random random = new Random();
      int result = random.nextInt(max + 1 - min) + min;
      return result;
   }

   public static float randomOffset(float f, float offset) {
      return f + ((new Random()).nextFloat() - 0.5F) * offset;
   }

   public static double randomOffset(double f, double offset) {
      return f + ((new Random()).nextDouble() - 0.5D) * offset;
   }

   public static double getNormalDouble(double d, int numberAfterZopyataya) {
      return (new BigDecimal(d)).setScale(numberAfterZopyataya, RoundingMode.HALF_EVEN).doubleValue();
   }

   public static double getNormalDouble(double d) {
      return (new BigDecimal(d)).setScale(2, RoundingMode.HALF_EVEN).doubleValue();
   }

   public static String getKeyFromInt(int i) {
      return Keyboard.getKeyName(i);
   }

   public static int getIntFromKey(String i) {
      return Keyboard.getKeyIndex(i);
   }

   public static double interpolatePartialTicks(double from, double to) {
      return from + (to - from) * (double)timer.b;
   }
}
