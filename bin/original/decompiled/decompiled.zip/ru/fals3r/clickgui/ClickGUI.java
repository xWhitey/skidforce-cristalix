package ru.fals3r.clickgui;

import java.awt.Color;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import org.lwjgl.opengl.GL11;
import ru.fals3r.SkidForce;
import ru.fals3r.clickgui.elements.Element;
import ru.fals3r.clickgui.elements.ModuleButton;
import ru.fals3r.clickgui.elements.menu.ElementSlider;
import ru.fals3r.functions.Category;
import ru.fals3r.functions.Function;
import ru.fals3r.settings.SettingsManager;

public class ClickGUI extends .blk {
   public static ArrayList<Panel> panels;
   public static ArrayList<Panel> rpanels;
   private ModuleButton mb = null;
   public SettingsManager setmgr;

   public ClickGUI() {
      this.setmgr = SkidForce.settingsManager;
      panels = new ArrayList();
      double pwidth = 105.0D;
      double pheight = 25.0D;
      double px = 10.0D;
      double py = 10.0D;
      double pyplus = pheight + 3.0D;
      Category[] var11 = Category.values();
      int var12 = var11.length;

      for(int var13 = 0; var13 < var12; ++var13) {
         final Category c = var11[var13];
         String title = Character.toUpperCase(c.name().toLowerCase().charAt(0)) + c.name().toLowerCase().substring(1);
         panels.add(new Panel(title, px, py, pwidth, pheight, true, this) {
            public void setup() {
               Iterator var1 = SkidForce.functionManager.functions().iterator();

               while(var1.hasNext()) {
                  Function f = (Function)var1.next();
                  if (f.getCategory().equals(c)) {
                     this.Elements.add(new ModuleButton(f, this));
                  }
               }

            }
         });
         px += pwidth + 5.0D;
      }

      rpanels = new ArrayList();
      Iterator var16 = panels.iterator();

      while(var16.hasNext()) {
         Panel p = (Panel)var16.next();
         rpanels.add(p);
      }

      Collections.reverse(rpanels);
   }

   public void e() {
      Iterator var1 = panels.iterator();

      while(var1.hasNext()) {
         Panel panel = (Panel)var1.next();
         Iterator var3 = panel.Elements.iterator();

         while(var3.hasNext()) {
            ModuleButton b = (ModuleButton)var3.next();
            Iterator var5 = b.menuelements.iterator();

            while(var5.hasNext()) {
               Element e = (Element)var5.next();
               e.tick();
               if (!panel.extended) {
                  e.anim = 0.0F;
                  e.anim2 = 0.0F;
               }

               if (!b.extended) {
                  e.anim = 0.0F;
                  e.anim2 = 0.0F;
               }
            }
         }
      }

   }

   public void a(int mouseX, int mouseY, float partialTicks) {
      .bir.a(0, 0, (new .bit(this.j)).a(), (new .bit(this.j)).b(), 1342177280);
      Iterator var4 = panels.iterator();

      Panel panel;
      while(var4.hasNext()) {
         panel = (Panel)var4.next();
         panel.drawScreen(mouseX, mouseY, partialTicks);
      }

      this.mb = null;
      var4 = panels.iterator();

      Iterator var6;
      ModuleButton b;
      label126:
      while(var4.hasNext()) {
         panel = (Panel)var4.next();
         if (panel != null && panel.visible && panel.extended && panel.Elements != null && panel.Elements.size() > 0) {
            var6 = panel.Elements.iterator();

            while(var6.hasNext()) {
               b = (ModuleButton)var6.next();
               if (b.listening) {
                  this.mb = b;
                  break label126;
               }
            }
         }
      }

      var4 = panels.iterator();

      label106:
      while(true) {
         do {
            do {
               do {
                  if (!var4.hasNext()) {
                     if (this.mb != null) {
                        .bit s = new .bit(this.j);
                        a(0, 0, this.l, this.m, -872415232);
                        GL11.glPushMatrix();
                        .bib.z().k.a("Bind Manager", (float)(s.a() / 2), (float)(s.b() / 2 - 30), -15558688);
                        .bib.z().k.a("Press any key...", (float)(s.a() / 2), (float)(s.b() / 2 - 10), -1);
                        .bib.z().k.a("'Escape' - unbound", (float)(s.a() / 2), (float)(s.b() / 2), -1);
                        GL11.glPopMatrix();
                     }

                     var4 = rpanels.iterator();

                     while(true) {
                        do {
                           do {
                              do {
                                 if (!var4.hasNext()) {
                                    super.a(mouseX, mouseY, partialTicks);
                                    return;
                                 }

                                 panel = (Panel)var4.next();
                              } while(!panel.extended);
                           } while(!panel.visible);
                        } while(panel.Elements == null);

                        for(var6 = panel.Elements.iterator(); var6.hasNext(); b = (ModuleButton)var6.next()) {
                        }
                     }
                  }

                  panel = (Panel)var4.next();
               } while(!panel.extended);
            } while(!panel.visible);
         } while(panel.Elements == null);

         var6 = panel.Elements.iterator();

         while(true) {
            do {
               do {
                  do {
                     if (!var6.hasNext()) {
                        continue label106;
                     }

                     b = (ModuleButton)var6.next();
                  } while(!b.extended);
               } while(b.menuelements == null);
            } while(b.menuelements.isEmpty());

            double off = 0.0D;
            Color temp = new Color(-13350562);
            int outlineColor = (new Color(temp.getRed(), temp.getGreen(), temp.getBlue(), 170)).getRGB();

            Element e;
            for(Iterator var12 = b.menuelements.iterator(); var12.hasNext(); off += e.height) {
               e = (Element)var12.next();
               e.offset = off;
               e.update();
               e.drawScreen(mouseX, mouseY, partialTicks);
            }
         }
      }
   }

   public void a(int mouseX, int mouseY, int mouseButton) {
      if (this.mb == null) {
         Iterator var4 = rpanels.iterator();

         label70:
         while(true) {
            Panel panel;
            do {
               do {
                  do {
                     if (!var4.hasNext()) {
                        var4 = rpanels.iterator();

                        do {
                           if (!var4.hasNext()) {
                              try {
                                 super.a(mouseX, mouseY, mouseButton);
                              } catch (IOException var10) {
                                 var10.printStackTrace();
                              }

                              return;
                           }

                           panel = (Panel)var4.next();
                        } while(!panel.mouseClicked(mouseX, mouseY, mouseButton));

                        return;
                     }

                     panel = (Panel)var4.next();
                  } while(!panel.extended);
               } while(!panel.visible);
            } while(panel.Elements == null);

            Iterator var6 = panel.Elements.iterator();

            while(true) {
               ModuleButton b;
               do {
                  if (!var6.hasNext()) {
                     continue label70;
                  }

                  b = (ModuleButton)var6.next();
               } while(!b.extended);

               Iterator var8 = b.menuelements.iterator();

               while(var8.hasNext()) {
                  Element e = (Element)var8.next();
                  if (e.mouseClicked(mouseX, mouseY, mouseButton)) {
                     return;
                  }
               }
            }
         }
      }
   }

   public void b(int mouseX, int mouseY, int state) {
      if (this.mb == null) {
         Iterator var4 = rpanels.iterator();

         label59:
         while(true) {
            Panel panel;
            do {
               do {
                  do {
                     if (!var4.hasNext()) {
                        var4 = rpanels.iterator();

                        while(var4.hasNext()) {
                           panel = (Panel)var4.next();
                           panel.mouseReleased(mouseX, mouseY, state);
                        }

                        super.b(mouseX, mouseY, state);
                        return;
                     }

                     panel = (Panel)var4.next();
                  } while(!panel.extended);
               } while(!panel.visible);
            } while(panel.Elements == null);

            Iterator var6 = panel.Elements.iterator();

            while(true) {
               ModuleButton b;
               do {
                  if (!var6.hasNext()) {
                     continue label59;
                  }

                  b = (ModuleButton)var6.next();
               } while(!b.extended);

               Iterator var8 = b.menuelements.iterator();

               while(var8.hasNext()) {
                  Element e = (Element)var8.next();
                  e.mouseReleased(mouseX, mouseY, state);
               }
            }
         }
      }
   }

   protected void a(char typedChar, int keyCode) {
      Iterator var3 = rpanels.iterator();

      while(true) {
         Panel p;
         do {
            do {
               do {
                  do {
                     do {
                        if (!var3.hasNext()) {
                           try {
                              super.a(typedChar, keyCode);
                           } catch (IOException var8) {
                              var8.printStackTrace();
                           }

                           return;
                        }

                        p = (Panel)var3.next();
                     } while(p == null);
                  } while(!p.visible);
               } while(!p.extended);
            } while(p.Elements == null);
         } while(p.Elements.size() <= 0);

         Iterator var5 = p.Elements.iterator();

         while(var5.hasNext()) {
            ModuleButton e = (ModuleButton)var5.next();

            try {
               if (e.keyTyped(typedChar, keyCode)) {
                  return;
               }
            } catch (IOException var9) {
               var9.printStackTrace();
            }
         }
      }
   }

   public void b() {
      Iterator var1 = panels.iterator();

      while(var1.hasNext()) {
         Panel panel = (Panel)var1.next();
         Iterator var3 = panel.Elements.iterator();

         while(var3.hasNext()) {
            ModuleButton b = (ModuleButton)var3.next();

            Element e;
            for(Iterator var5 = b.menuelements.iterator(); var5.hasNext(); e.anim2 = 0.0F) {
               e = (Element)var5.next();
               e.anim = 0.0F;
            }
         }
      }

   }

   public void m() {
      Iterator var1 = rpanels.iterator();

      label49:
      while(true) {
         Panel panel;
         do {
            do {
               do {
                  if (!var1.hasNext()) {
                     return;
                  }

                  panel = (Panel)var1.next();
               } while(!panel.extended);
            } while(!panel.visible);
         } while(panel.Elements == null);

         Iterator var3 = panel.Elements.iterator();

         while(true) {
            ModuleButton b;
            do {
               if (!var3.hasNext()) {
                  continue label49;
               }

               b = (ModuleButton)var3.next();
            } while(!b.extended);

            Iterator var5 = b.menuelements.iterator();

            while(var5.hasNext()) {
               Element e = (Element)var5.next();
               if (e instanceof ElementSlider) {
                  ((ElementSlider)e).dragging = false;
               }
            }
         }
      }
   }

   public void closeAllSettings() {
      Iterator var1 = rpanels.iterator();

      while(true) {
         Panel p;
         do {
            do {
               do {
                  do {
                     do {
                        if (!var1.hasNext()) {
                           return;
                        }

                        p = (Panel)var1.next();
                     } while(p == null);
                  } while(!p.visible);
               } while(!p.extended);
            } while(p.Elements == null);
         } while(p.Elements.size() <= 0);

         ModuleButton var4;
         for(Iterator var3 = p.Elements.iterator(); var3.hasNext(); var4 = (ModuleButton)var3.next()) {
         }
      }
   }
}
