package ru.fals3r.clickgui.elements.menu;

import java.awt.Color;
import java.util.Iterator;
import ru.fals3r.clickgui.elements.Element;
import ru.fals3r.clickgui.elements.ModuleButton;
import ru.fals3r.helpers.RenderHelper;
import ru.fals3r.settings.Setting;

public class ElementComboBox extends Element {
   public ElementComboBox(ModuleButton iparent, Setting iset) {
      this.parent = iparent;
      this.set = iset;
      super.setup();
   }

   public void drawScreen(int mouseX, int mouseY, float partialTicks) {
      Color temp = new Color(-13350562);
      int color = (new Color(temp.getRed(), temp.getGreen(), temp.getBlue(), 150)).getRGB();
      RenderHelper.drawRect(this.x, this.y, this.x + this.width, this.y + this.height, -2039584);
      RenderHelper.drawGradientSideways(this.x, this.y, this.x + this.width - 100.0D, this.y + this.height, -5460820, 14737632);
      RenderHelper.drawOctagon((float)this.x + 8.0F, (float)this.y + 1.0F, (float)this.width - 16.0F, 14.0F, 1.0F, 6.0F, -16746560);
      if (this.comboextended) {
         RenderHelper.drawRect(this.x + 12.0D, this.y + 15.0D, this.x + this.width - 12.0D, this.y + this.height, -2236963);
      }

      .bib.z().k.a(this.setstrg, (float)((int)(this.x + this.width / 2.0D - (double)(.bib.z().k.a(this.setstrg) / 2))), (float)((int)(this.y + 4.0D)), -1);
      int clr2 = temp.getRGB();
      if (this.comboextended) {
         double ay = this.y + 16.0D;

         for(Iterator var10 = this.set.getOptions().iterator(); var10.hasNext(); ay += (double)(.bib.z().k.a + 4)) {
            String sld = (String)var10.next();
            String elementtitle = sld.substring(0, 1).toUpperCase() + sld.substring(1, sld.length());
            .bib.z().k.a(elementtitle, (int)(this.x + this.width / 2.0D - (double)(.bib.z().k.a(elementtitle) / 2)), (int)(ay + 1.0D), sld.equalsIgnoreCase(this.set.getValString()) ? -16746560 : -12105913);
            if (sld.equalsIgnoreCase(this.set.getValString())) {
            }

            if ((double)mouseX >= this.x && (double)mouseX <= this.x + this.width && (double)mouseY >= ay && (double)mouseY < ay + (double).bib.z().k.a + 2.0D) {
            }
         }
      }

   }

   public boolean mouseClicked(int mouseX, int mouseY, int mouseButton) {
      if (mouseButton == 0) {
         if (this.isButtonHovered(mouseX, mouseY)) {
            this.comboextended = !this.comboextended;
            return true;
         }

         if (!this.comboextended) {
            return false;
         }

         double ay = this.y + 16.0D;

         for(Iterator var6 = this.set.getOptions().iterator(); var6.hasNext(); ay += (double)(.bib.z().k.a + 6)) {
            String slcd = (String)var6.next();
            if ((double)mouseX >= this.x && (double)mouseX <= this.x + this.width && (double)mouseY >= ay && (double)mouseY <= ay + (double).bib.z().k.a + 2.0D) {
               if (this.clickgui != null && this.clickgui.setmgr != null) {
                  this.clickgui.setmgr.getSettingByName(this.set.getName()).setValString(slcd.toLowerCase());
               }

               return true;
            }
         }
      }

      return super.mouseClicked(mouseX, mouseY, mouseButton);
   }

   public boolean isButtonHovered(int mouseX, int mouseY) {
      return (double)mouseX >= this.x && (double)mouseX <= this.x + this.width && (double)mouseY >= this.y && (double)mouseY <= this.y + 15.0D;
   }
}
