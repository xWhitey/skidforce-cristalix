package ru.fals3r.functions;

public class Function {
   private String name;
   private String mode = "";
   private int bind;
   private boolean toggled;
   private Category category;
   private long lastEnableTime;
   private long lastDisableTime;
   protected .bib mc = .bib.z();

   public Function() {
      this.registerSettings();
   }

   public void registerSettings() {
   }

   public void registerName(String str) {
      this.name = str;
   }

   public void registerMode(String str) {
      this.mode = str;
   }

   public void registerBind(int integer) {
      this.bind = integer;
   }

   public void registerCategory(Category cat) {
      this.category = cat;
   }

   public void toggle() {
      long enableTime;
      if (this.toggled) {
         enableTime = .bib.I() - this.lastEnableTime;
         this.lastDisableTime = .bib.I() - (enableTime < 300L ? 300L - enableTime : 0L);
         this.toggled = false;
         this.onDisable();
      } else {
         enableTime = .bib.I() - this.lastDisableTime;
         this.lastEnableTime = .bib.I() - (enableTime < 300L ? 300L - enableTime : 0L);
         this.toggled = true;
         this.onEnable();
      }

   }

   public void toggle(boolean bool) {
      if (bool != this.toggled) {
         this.toggle();
      }

   }

   public String getName() {
      return this.name;
   }

   public String getMode() {
      return this.mode;
   }

   public int getBind() {
      return this.bind;
   }

   public Category getCategory() {
      return this.category;
   }

   public boolean getToggled() {
      return this.toggled;
   }

   public double offset() {
      return (double)Math.abs(.rk.a((float)(.bib.I() - (this.toggled ? this.lastEnableTime : this.lastDisableTime)), -300.0F, 300.0F) / 300.0F);
   }

   public void onEnable() {
   }

   public void onDisable() {
   }

   public void onUpdate() {
   }

   public void onRender3D(float partialTicks) {
   }

   public void onRender2D(float partialTicks) {
   }
}
