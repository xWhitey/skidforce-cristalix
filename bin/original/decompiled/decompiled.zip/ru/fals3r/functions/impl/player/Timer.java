package ru.fals3r.functions.impl.player;

import java.lang.reflect.Field;
import ru.fals3r.SkidForce;
import ru.fals3r.functions.Category;
import ru.fals3r.functions.Function;
import ru.fals3r.helpers.MathHelper;

public class Timer extends Function {
   private .bih timer;
   Field tickLength;

   public Timer() {
      this.registerName("Timer");
      this.registerCategory(Category.Player);
      SkidForce.settingsManager.addDouble("Value", "TimerValue", 0.1D, 5.0D, 1.0D, this);
   }

   public void onUpdate() {
      try {
         this.tickLength.set(this.timer, (float)(50.0D / SkidForce.settingsManager.getSettingByName("TimerValue").getValDouble()));
      } catch (IllegalArgumentException var2) {
         var2.printStackTrace();
      } catch (IllegalAccessException var3) {
         var3.printStackTrace();
      }

   }

   public void onEnable() {
      Field tm = MathHelper.getField(.bib.class, "Y:field_71428_T:timer");

      try {
         this.timer = (.bih)tm.get(.bib.z());
      } catch (IllegalArgumentException var3) {
         var3.printStackTrace();
      } catch (IllegalAccessException var4) {
         var4.printStackTrace();
      }

      this.tickLength = MathHelper.getField(.bih.class, "e:tickLength");
   }

   public void onDisable() {
      try {
         this.tickLength.set(this.timer, 50.0F);
      } catch (IllegalArgumentException var2) {
         var2.printStackTrace();
      } catch (IllegalAccessException var3) {
         var3.printStackTrace();
      }

   }
}
