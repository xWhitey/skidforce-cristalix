package ru.fals3r.functions.impl.movement;

import java.util.ArrayList;
import ru.fals3r.SkidForce;
import ru.fals3r.functions.Category;
import ru.fals3r.functions.Function;
import ru.fals3r.helpers.MovementHelper;

public class Fly extends Function {
   public Fly() {
      this.registerName("Fly");
      this.registerCategory(Category.Movement);
      this.registerBind(33);
      ArrayList<String> flyMode = new ArrayList();
      flyMode.add("Creative");
      flyMode.add("Motion");
      SkidForce.settingsManager.addMode("Mode", "FlyMode", "Motion", flyMode, this);
      SkidForce.settingsManager.addDouble("Motion Value", "FlyMotionValue", 0.0D, 5.0D, 1.0D, this);
      SkidForce.settingsManager.addDouble("Motion-Y Value", "FlyMotionYValue", 0.0D, 2.0D, 0.5D, this);
   }

   public void onUpdate() {
      if (SkidForce.settingsManager.getSettingByName("FlyMode").getValString().equalsIgnoreCase("Motion")) {
         this.registerMode("В§7 Motion");
         this.mc.h.t = -0.1D;
         double y_val = SkidForce.settingsManager.getSettingByName("FlyMotionYValue").getValDouble();
         if (this.mc.t.X.e()) {
            this.mc.h.t = y_val;
         }

         if (this.mc.t.Y.e()) {
            this.mc.h.t = -y_val;
         }

         MovementHelper.setSpeed(SkidForce.settingsManager.getSettingByName("FlyMotionValue").getValDouble());
      } else if (SkidForce.settingsManager.getSettingByName("FlyMode").getValString().equalsIgnoreCase("Creative")) {
         this.registerMode("В§7 Creative");
      }

   }

   public void onEnable() {
      super.onEnable();
      if (SkidForce.settingsManager.getSettingByName("FlyMode").getValString().equalsIgnoreCase("Creative")) {
         this.mc.h.bO.b = true;
      }

   }

   public void onDisable() {
      super.onDisable();
      if (SkidForce.settingsManager.getSettingByName("FlyMode").getValString().equalsIgnoreCase("Creative")) {
         this.mc.h.bO.b = false;
      }

   }
}
