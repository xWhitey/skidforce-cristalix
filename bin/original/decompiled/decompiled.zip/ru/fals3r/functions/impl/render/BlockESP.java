package ru.fals3r.functions.impl.render;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import ru.fals3r.SkidForce;
import ru.fals3r.functions.Category;
import ru.fals3r.functions.Function;
import ru.fals3r.helpers.RenderHelper;

public class BlockESP extends Function {
   private .et nearestBlock;
   private long currentMS = 0L;
   protected long lastMS = -1L;
   private int range = 50;
   private int maxChests = 200;
   public boolean shouldInform = true;
   private ArrayList<.et> matchingBlocks = new ArrayList();
   private List<Integer[]> list = new ArrayList();

   public BlockESP() {
      this.registerName("BlockESP");
      this.registerCategory(Category.Render);
      SkidForce.settingsManager.addInt("Range", "XrayRange", 0, 500, 100, this);
      SkidForce.settingsManager.addBoolean("DiamondOre", "XrayDiamondOre", false, this);
      SkidForce.settingsManager.addBoolean("EmeraldOre", "XrayEmeraldOre", false, this);
      SkidForce.settingsManager.addBoolean("GoldOre", "XrayGoldOre", false, this);
      SkidForce.settingsManager.addBoolean("IronOre", "XrayIronOre", false, this);
      SkidForce.settingsManager.addBoolean("Spawner", "XraySpawner", false, this);
      SkidForce.settingsManager.addBoolean("Chests", "XrayChests", false, this);
      SkidForce.settingsManager.addBoolean("Lava", "XrayLava", false, this);
   }

   public void onRender3D(float partialTicks) {
      this.maxChests = (int)SkidForce.settingsManager.getSettingByName("XrayRange").getValDouble();
      int i = 0;
      Iterator var3 = this.matchingBlocks.iterator();

      while(var3.hasNext()) {
         .et blockPos = (.et)var3.next();
         if (i >= this.maxChests) {
            break;
         }

         ++i;
         if (this.getBlock(blockPos) == .aox.ag && SkidForce.settingsManager.getSettingByName("XrayDiamondOre").getValBoolean()) {
            RenderHelper.fuckerESP(blockPos, 0.2F, 0.5F, 1.0F);
         }

         if (this.getBlock(blockPos) == .aox.bP && SkidForce.settingsManager.getSettingByName("XrayEmeraldOre").getValBoolean()) {
            RenderHelper.fuckerESP(blockPos, 0.25F, 1.0F, 0.25F);
         }

         if (this.getBlock(blockPos) == .aox.o && SkidForce.settingsManager.getSettingByName("XrayGoldOre").getValBoolean()) {
            RenderHelper.fuckerESP(blockPos, 1.0F, 1.0F, 0.25F);
         }

         if (this.getBlock(blockPos) == .aox.p && SkidForce.settingsManager.getSettingByName("XrayIronOre").getValBoolean()) {
            RenderHelper.fuckerESP(blockPos, 0.7F, 0.7F, 0.7F);
         }

         if (this.getBlock(blockPos) == .aox.ac && SkidForce.settingsManager.getSettingByName("XraySpawner").getValBoolean()) {
            RenderHelper.fuckerESP(blockPos, 0.15F, 0.15F, 0.4F);
         }

         if (this.getBlock(blockPos) == .aox.ae && SkidForce.settingsManager.getSettingByName("XrayChests").getValBoolean()) {
            RenderHelper.fuckerESP(blockPos, 0.8F, 0.5F, 0.0F);
         }

         if (this.getBlock(blockPos) == .aox.l && SkidForce.settingsManager.getSettingByName("XrayLava").getValBoolean()) {
            RenderHelper.fuckerESP(blockPos, 1.0F, 0.5F, 0.15F);
         }
      }

      if (i >= this.maxChests && this.shouldInform) {
         this.shouldInform = false;
      } else if (i < this.maxChests) {
         this.shouldInform = true;
      }

   }

   public final void updateMS() {
      this.currentMS = System.currentTimeMillis();
   }

   public final void updateLastMS() {
      this.lastMS = System.currentTimeMillis();
   }

   public final boolean hasTimePassedM(long MS) {
      return this.currentMS >= this.lastMS + MS;
   }

   public final boolean hasTimePassedS(float speed) {
      return (float)this.currentMS >= (float)this.lastMS + 1000.0F / speed;
   }

   public void onUpdate() {
      this.updateMS();
      if (this.hasTimePassedM(3000L)) {
         this.matchingBlocks.clear();

         for(int y = this.range; y >= -this.range; --y) {
            for(int x = this.range; x >= -this.range; --x) {
               for(int z = this.range; z >= -this.range; --z) {
                  int posX = (int)(this.mc.h.p + (double)x);
                  int posY = (int)(this.mc.h.q + (double)y);
                  int posZ = (int)(this.mc.h.r + (double)z);
                  .et pos = new .et(posX, posY, posZ);
                  .awt state = this.mc.f.o(pos);
                  .aow block = state.u();
                  block.e(state);
                  if (this.validBlock(pos)) {
                     this.matchingBlocks.add(pos);
                  }
               }
            }
         }

         this.updateLastMS();
      }

   }

   public boolean validBlock(.et pos) {
      return this.getBlock(pos) == .aox.ag && SkidForce.settingsManager.getSettingByName("XrayDiamondOre").getValBoolean() || this.getBlock(pos) == .aox.bP && SkidForce.settingsManager.getSettingByName("XrayEmeraldOre").getValBoolean() || this.getBlock(pos) == .aox.o && SkidForce.settingsManager.getSettingByName("XrayGoldOre").getValBoolean() || this.getBlock(pos) == .aox.p && SkidForce.settingsManager.getSettingByName("XrayIronOre").getValBoolean() || this.getBlock(pos) == .aox.ac && SkidForce.settingsManager.getSettingByName("XraySpawner").getValBoolean() || this.getBlock(pos) == .aox.ae && SkidForce.settingsManager.getSettingByName("XrayChests").getValBoolean() || this.getBlock(pos) == .aox.l && SkidForce.settingsManager.getSettingByName("XrayLava").getValBoolean();
   }

   public .et getFixedLocation() {
      return new .et(this.mc.h.p < 0.0D ? (int)this.mc.h.p - 1 : (int)this.mc.h.p, (int)this.mc.h.q, this.mc.h.r < 0.0D ? (int)this.mc.h.r - 1 : (int)this.mc.h.r);
   }

   public .aow getBlock(.et pos) {
      return this.mc.f.o(pos).u();
   }

   public float getPlayerBlockDistance(.et pos) {
      .vg e = this.mc.h;
      .bhe pPos = e.d().b(0.0D, (double)e.by(), 0.0D);
      return .rk.a(pPos.c((double)((float)pos.p() + 0.5F), (double)((float)pos.q() + 0.5F), (double)((float)pos.r() + 0.5F)));
   }

   private .et getNearestBlock() {
      int r = (int)SkidForce.settingsManager.getSettingByName("XrayRange").getValDouble();

      for(int y = -r; y <= r; ++y) {
         for(int x = -r; x <= r; ++x) {
            for(int z = -r; z <= r; ++z) {
               .et pos = this.getFixedLocation().a(x, y, z);
               if (this.validBlock(pos)) {
                  return pos;
               }
            }
         }
      }

      return null;
   }
}
