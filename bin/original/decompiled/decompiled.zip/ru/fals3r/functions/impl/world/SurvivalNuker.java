package ru.fals3r.functions.impl.world;

import ru.fals3r.SkidForce;
import ru.fals3r.functions.Category;
import ru.fals3r.functions.Function;
import ru.fals3r.helpers.TimeHelper;

public class SurvivalNuker extends Function {
   public int tick;
   public TimeHelper timer = new TimeHelper();

   public SurvivalNuker() {
      this.registerName("SurvivalNuker");
      this.registerCategory(Category.World);
      SkidForce.settingsManager.addInt("Range", "SurvivalNukerRange", 1, 20, 5, this);
      SkidForce.settingsManager.addInt("Tick Delay", "SurvivalNukerTickDelay", 0, 10, 2, this);
      SkidForce.settingsManager.addInt("Timer Delay", "SurvivalNukerTimerDelay", 0, 300, 100, this);
      SkidForce.settingsManager.addBoolean("Use timer delay", "SurvivalNukerUseTimerDelay", false, this);
      SkidForce.settingsManager.addBoolean("Swing", "SurvivalNukerSwing", true, this);
      SkidForce.settingsManager.addBoolean("Save Floor", "SurvivalNukerSaveFloor", true, this);
      SkidForce.settingsManager.addBoolean("Dirt", "SurvivalNukerDirt", true, this);
      SkidForce.settingsManager.addBoolean("Sand", "SurvivalNukerSand", true, this);
      SkidForce.settingsManager.addBoolean("Gravel", "SurvivalNukerGravel", true, this);
      SkidForce.settingsManager.addBoolean("Ore", "SurvivalNukerOre", true, this);
      SkidForce.settingsManager.addBoolean("Stone", "SurvivalNukerStone", true, this);
      SkidForce.settingsManager.addBoolean("Coal Block", "SurvivalNukerCoalBlock", true, this);
      SkidForce.settingsManager.addBoolean("End Brick", "SurvivalNukerEndBrick", true, this);
      SkidForce.settingsManager.addBoolean("Log", "SurvivalNukerLog", true, this);
      SkidForce.settingsManager.addBoolean("Quartz", "SurvivalNukerQuartz", true, this);
      SkidForce.settingsManager.addBoolean("Ice", "SurvivalNukerIce", true, this);
      SkidForce.settingsManager.addBoolean("Packed Ice", "SurvivalNukerPackedIce", true, this);
      SkidForce.settingsManager.addBoolean("Wool", "SurvivalNukerWool", true, this);
      SkidForce.settingsManager.addBoolean("Web", "SurvivalNukerWeb", true, this);
      SkidForce.settingsManager.addBoolean("Nether Brick", "SurvivalNukerNetherBrick", true, this);
      SkidForce.settingsManager.addBoolean("Purpur Block", "SurvivalNukerPurpurBlock", true, this);
      SkidForce.settingsManager.addBoolean("Clay", "SurvivalNukerClay", true, this);
      SkidForce.settingsManager.addBoolean("Sandstone", "SurvivalNukerSandStone", true, this);
   }

   public boolean isValidBlock(.aow b) {
      if (b instanceof .apy && SkidForce.settingsManager.getSettingByName("SurvivalNukerDirt").getValBoolean()) {
         return true;
      } else if (b instanceof .atn && SkidForce.settingsManager.getSettingByName("SurvivalNukerSand").getValBoolean()) {
         return true;
      } else if (b instanceof .ard && SkidForce.settingsManager.getSettingByName("SurvivalNukerGravel").getValBoolean()) {
         return true;
      } else if (b instanceof .asp && SkidForce.settingsManager.getSettingByName("SurvivalNukerOre").getValBoolean()) {
         return true;
      } else if (b instanceof .auh && SkidForce.settingsManager.getSettingByName("SurvivalNukerStone").getValBoolean()) {
         return true;
      } else if (b == .aox.cA && SkidForce.settingsManager.getSettingByName("SurvivalNukerCoalBlock").getValBoolean()) {
         return true;
      } else if (b == .aox.cY && SkidForce.settingsManager.getSettingByName("SurvivalNukerEndBrick").getValBoolean()) {
         return true;
      } else if (b instanceof .arv && SkidForce.settingsManager.getSettingByName("SurvivalNukerLog").getValBoolean()) {
         return true;
      } else if (b instanceof .ata && SkidForce.settingsManager.getSettingByName("SurvivalNukerQuartz").getValBoolean()) {
         return true;
      } else if (b instanceof .aro && SkidForce.settingsManager.getSettingByName("SurvivalNukerIce").getValBoolean()) {
         return true;
      } else if (b instanceof .asq && SkidForce.settingsManager.getSettingByName("SurvivalNukerPackedIce").getValBoolean()) {
         return true;
      } else if (b == .aox.L && SkidForce.settingsManager.getSettingByName("SurvivalNukerWool").getValBoolean()) {
         return true;
      } else if (b instanceof .auz && SkidForce.settingsManager.getSettingByName("SurvivalNukerWeb").getValBoolean()) {
         return true;
      } else if (b instanceof .asd && SkidForce.settingsManager.getSettingByName("SurvivalNukerNetherBrick").getValBoolean()) {
         return true;
      } else if (b == .aox.cT && SkidForce.settingsManager.getSettingByName("SurvivalNukerPurpurBlock").getValBoolean()) {
         return true;
      } else if (b == .aox.aL && SkidForce.settingsManager.getSettingByName("SurvivalNukerClay").getValBoolean()) {
         return true;
      } else if (b == .aox.cz && SkidForce.settingsManager.getSettingByName("SurvivalNukerClay").getValBoolean()) {
         return true;
      } else if (b == .aox.cu && SkidForce.settingsManager.getSettingByName("SurvivalNukerClay").getValBoolean()) {
         return true;
      } else if (b == .aox.A && SkidForce.settingsManager.getSettingByName("SurvivalNukerSandStone").getValBoolean()) {
         return true;
      } else {
         return b == .aox.cM && SkidForce.settingsManager.getSettingByName("SurvivalNukerSandStone").getValBoolean();
      }
   }

   public void onUpdate() {
      ++this.tick;
      double range = SkidForce.settingsManager.getSettingByName("SurvivalNukerRange").getValDouble();
      int radius = 6;
      int blocksMined = false;

      for(int x = -radius; x <= radius; ++x) {
         for(int y = -radius; y <= radius; ++y) {
            for(int z = -radius; z <= radius; ++z) {
               .et pos = new .et(this.mc.h.p + (double)x, this.mc.h.q + (double)this.mc.h.by() + (double)y, this.mc.h.r + (double)z);
               if ((!((double)pos.q() < this.mc.h.q) || !SkidForce.settingsManager.getSettingByName("SurvivalNukerSaveFloor").getValBoolean()) && Math.sqrt(this.mc.h.c((.et)pos)) < (double)this.mc.c.d()) {
                  int delay = (int)SkidForce.settingsManager.getSettingByName("SurvivalNukerTickDelay").getValDouble();
                  long timerDelay = (long)SkidForce.settingsManager.getSettingByName("SurvivalNukerTimerDelay").getValDouble();
                  if (SkidForce.settingsManager.getSettingByName("SurvivalNukerUseTimerDelay").getValBoolean()) {
                     if (this.timer.hasTimePassedM(timerDelay) && this.isValidBlock(this.mc.f.o(pos).u())) {
                        this.mc.h.d.a((.ht)(new .lp(.lp$a.a, pos, .fa.a)));
                        this.mc.h.d.a((.ht)(new .lp(.lp$a.c, pos, .fa.a)));
                        this.mc.h.d.a((.ht)(new .lp(.lp$a.a, pos, .fa.a)));
                        if (SkidForce.settingsManager.getSettingByName("SurvivalNukerSwing").getValBoolean()) {
                           this.mc.h.a(.ub.a);
                        }

                        this.timer.updateLastMS();
                     }
                  } else if (this.tick > delay - 1 && this.isValidBlock(this.mc.f.o(pos).u())) {
                     this.mc.h.d.a((.ht)(new .lp(.lp$a.a, pos, .fa.a)));
                     this.mc.h.d.a((.ht)(new .lp(.lp$a.c, pos, .fa.a)));
                     this.mc.h.d.a((.ht)(new .lp(.lp$a.a, pos, .fa.a)));
                     if (SkidForce.settingsManager.getSettingByName("SurvivalNukerSwing").getValBoolean()) {
                        this.mc.h.a(.ub.a);
                     }

                     this.tick = 0;
                  }
               }
            }
         }
      }

   }
}
