package ru.fals3r.functions.impl.player;

import java.lang.reflect.Field;
import ru.fals3r.functions.Category;
import ru.fals3r.functions.Function;
import ru.fals3r.helpers.MathHelper;

public class SpeedMine extends Function {
   private Field curBlockDamageMP;
   private Field blockHitDelay;

   public SpeedMine() {
      this.registerName("SpeedMine");
      this.registerCategory(Category.Player);
   }

   public void onUpdate() {
      try {
         this.curBlockDamageMP.set(this.mc.c, 1.0F);
         this.blockHitDelay.set(this.mc.c, 0);
      } catch (IllegalArgumentException var2) {
         var2.printStackTrace();
      } catch (IllegalAccessException var3) {
         var3.printStackTrace();
      }

   }

   public void onEnable() {
      this.curBlockDamageMP = MathHelper.getField(.bsa.class, "e:curBlockDamageMP");
      this.blockHitDelay = MathHelper.getField(.bsa.class, "g:blockHitDelay");
   }

   public void onDisable() {
   }
}
