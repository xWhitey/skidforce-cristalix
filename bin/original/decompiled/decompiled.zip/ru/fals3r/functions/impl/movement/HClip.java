package ru.fals3r.functions.impl.movement;

import ru.fals3r.SkidForce;
import ru.fals3r.functions.Category;
import ru.fals3r.functions.Function;
import ru.fals3r.helpers.MovementHelper;

public class HClip extends Function {
   public HClip() {
      this.registerName("HClip");
      this.registerCategory(Category.Movement);
      SkidForce.settingsManager.addDouble("Value", "HClipValue", 0.0D, 10.0D, 2.0D, this);
      SkidForce.settingsManager.addBoolean("Improve", "HClipImprove", false, this);
   }

   public void onEnable() {
      double h_val = SkidForce.settingsManager.getSettingByName("HClipValue").getValDouble();
      double posX = this.mc.h.p - Math.sin((double)MovementHelper.getDirection()) * h_val;
      double posZ = this.mc.h.r + Math.cos((double)MovementHelper.getDirection()) * h_val;
      if (SkidForce.settingsManager.getSettingByName("HClipImprove").getValBoolean()) {
         this.mc.h.a(posX, this.mc.h.q, posZ);
      } else {
         this.mc.h.b(posX, this.mc.h.q, posZ);
      }

      this.toggle(false);
   }
}
