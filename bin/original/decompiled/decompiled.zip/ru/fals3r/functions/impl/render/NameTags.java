package ru.fals3r.functions.impl.render;

import java.util.Iterator;
import org.lwjgl.opengl.GL11;
import ru.fals3r.functions.Category;
import ru.fals3r.functions.Function;

public class NameTags extends Function {
   public NameTags() {
      this.registerName("NameTags");
      this.registerCategory(Category.Render);
   }

   public void onRender3D(float partialTicks) {
      .aed target = null;
      Iterator var3 = this.mc.f.e.iterator();

      while(var3.hasNext()) {
         Object o = var3.next();
         if (o instanceof .aed) {
            .aed entity = (.aed)o;
            if (entity instanceof .aed && entity != this.mc.h) {
               this.handleEntity(entity, partialTicks);
            }
         }
      }

   }

   public void handleEntity(.vg entityIn, float partialTicks) {
      double maxDistance = 1337.0D;
      double d0 = entityIn.h(this.mc.ac().c);
      if (d0 <= maxDistance * maxDistance) {
         boolean flag = entityIn.aU();
         float f = this.mc.ac().e;
         float f1 = this.mc.ac().f;
         boolean flag1 = this.mc.ac().g.aw == 2;
         float f2 = entityIn.H + 0.5F - (flag ? 0.25F : 0.0F);
         int i = "deadmau5".equals(entityIn.h_()) ? -10 : 0;
         double x = entityIn.M + (entityIn.p - entityIn.M) * (double)partialTicks - .bwx.b;
         double y = entityIn.N + (entityIn.q - entityIn.N) * (double)partialTicks - .bwx.c;
         double z = entityIn.O + (entityIn.r - entityIn.O) * (double)partialTicks - .bwx.d;
         this.renderNametag(this.mc.k, entityIn, entityIn.i_().d() + " В§c| " + (int)((.vp)entityIn).cd() + " HPВ§r", (float)x, (float)y + f2, (float)z, i, f, f1, flag1, flag);
      }

   }

   public void renderNametag(.bip fontRendererIn, .vg ent, String str, float x, float y, float z, int verticalShift, float viewerYaw, float viewerPitch, boolean isThirdPersonFrontal, boolean isSneaking) {
      .bus.G();
      .bus.c(x, y, z);
      .bus.a(0.0F, 1.0F, 0.0F);
      .bus.b(-viewerYaw, 0.0F, 1.0F, 0.0F);
      .bus.b((float)(isThirdPersonFrontal ? -1 : 1) * viewerPitch, 1.0F, 0.0F, 0.0F);
      float var13 = this.mc.h.g(ent) / 10.0F;
      if (var13 < 0.6F) {
         var13 = 0.6F;
      }

      var13 /= 35.0F;
      .bus.b(-var13, -var13, var13);
      .bus.g();
      .bus.a(false);
      if (!isSneaking) {
         .bus.j();
      }

      GL11.glEnable(3042);
      .bus.m();
      .bus.a(.bus$r.l, .bus$l.j, .bus$r.e, .bus$l.n);
      int i = fontRendererIn.a(str) / 2;
      .bus.z();
      .bve tessellator = .bve.a();
      .buk bufferbuilder = tessellator.c();
      bufferbuilder.a(7, .cdy.f);
      bufferbuilder.b((double)(-i - 1), (double)(-1 + verticalShift), 0.0D).a(0.0F, 0.0F, 0.0F, 0.25F).d();
      bufferbuilder.b((double)(-i - 1), (double)(8 + verticalShift), 0.0D).a(0.0F, 0.0F, 0.0F, 0.25F).d();
      bufferbuilder.b((double)(i + 1), (double)(8 + verticalShift), 0.0D).a(0.0F, 0.0F, 0.0F, 0.25F).d();
      bufferbuilder.b((double)(i + 1), (double)(-1 + verticalShift), 0.0D).a(0.0F, 0.0F, 0.0F, 0.25F).d();
      tessellator.b();
      .bus.y();
      GL11.glDisable(3042);
      if (!isSneaking) {
         fontRendererIn.a(str, -fontRendererIn.a(str) / 2, verticalShift, 553648127);
         .bus.k();
      }

      .bus.a(true);
      fontRendererIn.a(str, -fontRendererIn.a(str) / 2, verticalShift, isSneaking ? 553648127 : -1);
      .bus.f();
      .bus.l();
      .bus.c(1.0F, 1.0F, 1.0F, 1.0F);
      .bus.H();
   }

   public void nametags(.aed entity, String tag, double pX, double pY, double pZ) {
      .bip var12 = this.mc.k;
      pY += 0.9D;
      float var13 = this.mc.h.g(entity) / 10.0F;
      if (var13 < 1.6F) {
         var13 = 1.6F;
      }

      if (entity instanceof .vp) {
         if (entity instanceof .aed) {
            double health = Math.ceil((double)entity.cd()) / 2.0D;
            tag = tag + " В§cHP: " + (int)health;
         }

         .bzf renderManager = this.mc.ac();
         int color = 16776960;
         float scale = var13 * 2.0F;
         scale /= 100.0F;
         GL11.glPushMatrix();
         GL11.glTranslatef((float)pX, (float)pY + 1.5F, (float)pZ);
         GL11.glNormal3f(0.0F, 1.0F, 0.0F);
         GL11.glRotatef(-renderManager.e, 0.0F, 1.0F, 0.0F);
         GL11.glRotatef(renderManager.f, 1.0F, 0.0F, 0.0F);
         GL11.glScalef(-scale, -scale, scale);
         GL11.glDisable(2896);
         GL11.glDisable(2929);
         .bve var14 = .bve.a();
         .buk var15 = var14.c();
         int width = this.mc.k.a(tag) / 2;
         GL11.glEnable(3042);
         GL11.glBlendFunc(770, 771);
         .bir.a(-width - 1, -1, width + 1, this.mc.k.a, 1879048192);
         this.mc.k.a(tag, -width, 0, 16777215);
         GL11.glDisable(3042);
         GL11.glEnable(2896);
         GL11.glEnable(2929);
         GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
         GL11.glPopMatrix();
      }

   }
}
