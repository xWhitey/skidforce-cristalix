package ru.fals3r.functions.impl.movement;

import java.util.ArrayList;
import ru.fals3r.SkidForce;
import ru.fals3r.functions.Category;
import ru.fals3r.functions.Function;
import ru.fals3r.helpers.MovementHelper;

public class Speed extends Function {
   public int tick;

   public Speed() {
      this.registerName("Speed");
      this.registerCategory(Category.Movement);
      this.registerBind(47);
      ArrayList<String> speedMode = new ArrayList();
      speedMode.add("Legit");
      speedMode.add("DoodleJump");
      speedMode.add("Motion");
      SkidForce.settingsManager.addMode("Mode", "SpeedMode", "Motion", speedMode, this);
      SkidForce.settingsManager.addDouble("Motion Value", "SpeedValue", 0.0D, 5.0D, 1.0D, this);
   }

   public void onUpdate() {
      if (SkidForce.settingsManager.getSettingByName("SpeedMode").getValString().equalsIgnoreCase("Motion")) {
         this.registerMode("В§7 Motion");
         MovementHelper.setSpeed(SkidForce.settingsManager.getSettingByName("SpeedValue").getValDouble());
      } else if (SkidForce.settingsManager.getSettingByName("SpeedMode").getValString().equalsIgnoreCase("Legit")) {
         this.registerMode("В§7 Legit");
         ++this.tick;
         if (this.tick >= 15) {
            this.tick = 0;
            .bud var10000 = this.mc.h;
            var10000.u *= 1.45D;
         }
      } else if (SkidForce.settingsManager.getSettingByName("SpeedMode").getValString().equalsIgnoreCase("DoodleJump") && this.mc.h.z) {
         this.registerMode("В§7 DoodleJump");
         this.mc.h.cu();
         this.mc.h.cu();
         this.mc.h.cu();
      }

   }
}
