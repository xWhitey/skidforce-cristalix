package ru.fals3r.functions.impl.movement;

import ru.fals3r.SkidForce;
import ru.fals3r.functions.Category;
import ru.fals3r.functions.Function;

public class VClip extends Function {
   public VClip() {
      this.registerName("VClip");
      this.registerCategory(Category.Movement);
      SkidForce.settingsManager.addDouble("Value", "VClipValue", 0.0D, 10.0D, 2.0D, this);
      SkidForce.settingsManager.addBoolean("Up", "VClipUp", false, this);
      SkidForce.settingsManager.addBoolean("Improve", "VClipImprove", false, this);
   }

   public void onEnable() {
      if (SkidForce.settingsManager.getSettingByName("VClipUp").getValBoolean()) {
         if (SkidForce.settingsManager.getSettingByName("VClipImprove").getValBoolean()) {
            this.mc.h.a(this.mc.h.p, this.mc.h.q + SkidForce.settingsManager.getSettingByName("VClipValue").getValDouble(), this.mc.h.r);
         } else {
            this.mc.h.b(this.mc.h.p, this.mc.h.q + SkidForce.settingsManager.getSettingByName("VClipValue").getValDouble(), this.mc.h.r);
         }
      } else if (SkidForce.settingsManager.getSettingByName("VClipImprove").getValBoolean()) {
         this.mc.h.a(this.mc.h.p, this.mc.h.q - SkidForce.settingsManager.getSettingByName("VClipValue").getValDouble(), this.mc.h.r);
      } else {
         this.mc.h.b(this.mc.h.p, this.mc.h.q - SkidForce.settingsManager.getSettingByName("VClipValue").getValDouble(), this.mc.h.r);
      }

      this.toggle(false);
   }
}
