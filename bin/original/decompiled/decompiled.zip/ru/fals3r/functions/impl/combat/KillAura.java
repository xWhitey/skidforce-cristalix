package ru.fals3r.functions.impl.combat;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import ru.fals3r.SkidForce;
import ru.fals3r.functions.Category;
import ru.fals3r.functions.Function;
import ru.fals3r.helpers.TimeHelper;

public class KillAura extends Function {
   public .vp target;
   public TimeHelper timer = new TimeHelper();

   public KillAura() {
      this.registerName("KillAura");
      this.registerCategory(Category.Combat);
      this.registerBind(19);
      SkidForce.settingsManager.addDouble("Range", "KillauraRange", 0.0D, 10.0D, 6.0D, this);
      SkidForce.settingsManager.addDouble("Delay", "KillauraDelay", 0.0D, 1500.0D, 200.0D, this);
      SkidForce.settingsManager.addBoolean("1.9 Clicks", "Killaura19Clicks", true, this);
      SkidForce.settingsManager.addBoolean("Players only", "KillauraPlayersOnly", false, this);
   }

   public void onUpdate() {
      if (!(this.mc.h.n(0.0F) < 1.0F) || !SkidForce.settingsManager.getSettingByName("Killaura19Clicks").getValBoolean()) {
         if (this.target == null || !this.validEntity(this.target) || (double)this.mc.h.g(this.target) > SkidForce.settingsManager.getSettingByName("KillauraRange").getValDouble()) {
            this.target = this.getTarget();
         }

         if (this.target != null && this.validEntity(this.target) && (double)this.mc.h.g(this.target) <= SkidForce.settingsManager.getSettingByName("KillauraRange").getValDouble() && this.timer.hasTimePassedM((long)SkidForce.settingsManager.getSettingByName("KillauraDelay").getValDouble())) {
            this.mc.c.a((.aed)this.mc.h, (.vg)this.target);
            this.mc.h.a(.ub.a);
            this.timer.updateLastMS();
         }

      }
   }

   public .vp getTarget() {
      List<.vp> entities = this.mc.f.a(.vp.class, this::validEntity);
      return entities.isEmpty() ? null : (.vp)Collections.min(entities, Comparator.comparingDouble(.vp::cd));
   }

   public boolean validEntity(.vp ent) {
      if (SkidForce.settingsManager.getSettingByName("KillauraPlayersOnly").getValBoolean() && !(ent instanceof .aed)) {
         return false;
      } else {
         return ent != this.mc.h && ent.S() != -69 && ent.aB == 0 && ent.bd() && this.getDistFromEyesToEnt(ent) <= SkidForce.settingsManager.getSettingByName("KillauraRange").getValDouble() && (!(ent instanceof .wb) || ((.wb)ent).do() == null || !((.wb)ent).do().h_().equals(this.mc.h.h_())) && !(ent instanceof .abz);
      }
   }

   public double getDistFromEyesToEnt(.vg ent) {
      .bhe eyes = this.mc.h.f(1.0F).b(this.mc.h.s, this.mc.h.t, this.mc.h.u);
      return eyes.f(ent.d().b(ent.s, ent.t, ent.u));
   }

   private double getDistanceToEntityCenter(.vg ent) {
      return getAngleFromVectors(this.mc.h.e(1.0F), ent.f(1.0F).d(this.mc.h.f(1.0F)));
   }

   public static double getAngleFromVectors(.bhe vec1, .bhe vec2) {
      return (1.0D - vec1.b(vec2) / (vec1.b() * vec2.b())) * 180.0D;
   }
}
