package ru.fals3r.functions.impl.render;

import java.util.ArrayList;
import java.util.Iterator;
import ru.fals3r.SkidForce;
import ru.fals3r.functions.Category;
import ru.fals3r.functions.Function;
import ru.fals3r.helpers.RenderHelper;

public class PlayerESP extends Function {
   public PlayerESP() {
      this.registerName("PlayerESP");
      this.registerCategory(Category.Render);
      this.registerBind(21);
      ArrayList<String> mode = new ArrayList();
      mode.add("3D Box");
      mode.add("Outline");
      SkidForce.settingsManager.addMode("Mode", "PlayerESPMode", "Outline", mode, this);
   }

   public void onUpdate() {
      if (SkidForce.settingsManager.getSettingByName("PlayerESPMode").getValString().equalsIgnoreCase("Outline")) {
         Iterator var1 = this.mc.f.e.iterator();

         while(var1.hasNext()) {
            .vg e = (.vg)var1.next();
            if (e instanceof .vp && e instanceof .aed) {
               e.g(true);
            }
         }
      }

   }

   public void onRender3D(float partialTicks) {
      if (SkidForce.settingsManager.getSettingByName("PlayerESPMode").getValString().equalsIgnoreCase("3D Box")) {
         Iterator var2 = this.mc.f.e.iterator();

         while(var2.hasNext()) {
            .vg e = (.vg)var2.next();
            if (e instanceof .vp && e instanceof .aed) {
               RenderHelper.entityESPBox(e, 0.2F, 0.6F, 1.0F, 1.0F);
            }
         }
      }

   }

   public void onDisable() {
      if (SkidForce.settingsManager.getSettingByName("PlayerESPMode").getValString().equalsIgnoreCase("Outline")) {
         Iterator var1 = this.mc.f.e.iterator();

         while(var1.hasNext()) {
            .vg e = (.vg)var1.next();
            if (e instanceof .vp && e instanceof .aed) {
               e.g(false);
            }
         }
      }

   }
}
