package ru.fals3r.functions;

public enum Category {
   Combat,
   Movement,
   Render,
   Player,
   World;
}
