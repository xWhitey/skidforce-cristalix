package ru.fals3r.hooks;

import java.lang.reflect.Field;
import java.util.Iterator;
import org.lwjgl.input.Keyboard;
import ru.fals3r.SkidForce;
import ru.fals3r.functions.Function;
import ru.fals3r.render.InGameRender;

public class ProfillerHook extends .rl {
   public static .bib mc;
   public static .bih timer;
   private boolean[] keyStates;

   public ProfillerHook() {
      this.initHiddenFields();
   }

   public void a(String name) {
      Iterator var2 = SkidForce.functionManager.functions().iterator();

      Function func;
      while(var2.hasNext()) {
         func = (Function)var2.next();
         if (this.checkKey(func.getBind())) {
            func.toggle();
         }
      }

      this.initOtherHooks();
      if (name == "gui") {
         mc.o.j();
         InGameRender.doRender();
         var2 = SkidForce.functionManager.functions().iterator();

         while(var2.hasNext()) {
            func = (Function)var2.next();
            if (func.getToggled()) {
               func.onRender2D(timer.b);
            }
         }
      }

      if (name == "hand") {
         var2 = SkidForce.functionManager.functions().iterator();

         while(var2.hasNext()) {
            func = (Function)var2.next();
            if (func.getToggled()) {
               func.onRender3D(timer.b);
            }
         }
      }

      super.a(name);
   }

   public void initOtherHooks() {
      if (mc.h != null && !(mc.h.e instanceof MovementHook)) {
         mc.h.e = new MovementHook(mc.t);
      }

   }

   public void initHiddenFields() {
      mc = .bib.z();
      this.keyStates = new boolean[256];

      try {
         Field f = this.getField(.bib.class, "B:field_71424_I:profiler");
         Field modifiersField = this.getField(Field.class, "modifiers");
         modifiersField.setInt(f, f.getModifiers() & -17);
         f.set(.bib.z(), this);
         Field tm = this.getField(.bib.class, "Y:field_71428_T:timer");
         timer = (.bih)tm.get(.bib.z());
      } catch (Exception var4) {
      }

   }

   public Field getField(Class cl, String name) {
      String[] var6;
      int var5 = (var6 = name.split(":")).length;
      int var7 = 0;

      while(var7 < var5) {
         String s1 = var6[var7];

         try {
            Field f = cl.getDeclaredField(s1);
            f.setAccessible(true);
            return f;
         } catch (Exception var8) {
            ++var7;
         }
      }

      return null;
   }

   public boolean checkKey(int i) {
      boolean b;
      if (mc.m != null) {
         b = false;
      } else if (Keyboard.isKeyDown(i) != this.keyStates[i]) {
         boolean[] keyStates = this.keyStates;
         b = !this.keyStates[i];
         keyStates[i] = b;
      } else {
         b = false;
      }

      return b;
   }
}
