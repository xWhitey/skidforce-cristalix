package ru.fals3r.hooks;

import java.util.Iterator;
import ru.fals3r.SkidForce;
import ru.fals3r.functions.Function;

public class MovementHook extends .buc {
   public MovementHook(.bid gameSettingsIn) {
      super(gameSettingsIn);
   }

   public void a() {
      super.a();
      Iterator var1 = SkidForce.functionManager.functions().iterator();

      while(var1.hasNext()) {
         Function func = (Function)var1.next();
         if (func.getToggled()) {
            func.onUpdate();
         }
      }

   }
}
